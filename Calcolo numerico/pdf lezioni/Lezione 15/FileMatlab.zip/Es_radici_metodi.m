%Esercizio calcolo radici con metodi implementati
clear
clc
close all

funz=@(x) x.^3-6*x.^2+11*x-6;
a=0; b=1.5;
x=linspace(a,b);
toll=10^-6;
nmax=100;
plot(x,funz(x))
grid on
%metodo di bisezione
[xvect_b,fx_b,nit_b]=bisect(funz,a,b,toll,nmax)
% errore sulla soluzione esatta
errore_b=abs(xvect_b-1)
%metodo delle corde
x0=(a+b)/2;
[xvect_c,fx_c,nit_c]=chord(a,b,x0,nmax,toll,funz)
% errore sulla soluzione esatta
errore=abs(xvect_c-1)

