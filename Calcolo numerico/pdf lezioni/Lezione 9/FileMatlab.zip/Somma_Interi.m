% somma primi numeri interi
clear
clc

N=100;
S=0;
for i=1:N
    S=S+i;
end