% Esercizio 2 scheda grafici Matlab
close all
clear
clc

for M=1:6 %M=[2 3 7];
    [x,y]=funz(M); 
    semilogy(x,y); %plot(x,y) % grafico
    hold on
end
grid on
figure
M=1;
while M<7
    subplot(2,3,M)
    [x,y]=funz(M);
    plot(x,y)
    grid on
    title(M)
    M=M+1;
end
    
