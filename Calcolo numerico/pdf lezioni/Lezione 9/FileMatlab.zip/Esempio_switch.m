clear
clc

x=10.5;
z=rem(x,2);
switch z
    case 0
        xx=x/2+1
    case 1
        xx=3*x-1
    otherwise
        disp('non hai inserito un numero intero')
end