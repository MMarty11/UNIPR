function [ascisse,ordinate]=funz(m)
% funzione definita a tratti
x1=linspace(-m,0);
y1=(m-x1.^2/m).^m;
x2=linspace(0,m);
y2=(m+x2.^2/m).^m;
ascisse=[x1 x2];
ordinate=[y1 y2];
