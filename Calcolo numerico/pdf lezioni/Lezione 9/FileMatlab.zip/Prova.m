clear 
clc

x=linspace(0,pi);
y=sin(x);
save lavoro