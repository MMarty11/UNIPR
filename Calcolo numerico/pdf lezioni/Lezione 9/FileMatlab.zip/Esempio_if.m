clear
clc
close all

a=-5;
if a<0
    a=-1
elseif a>0
    a=1
else
    disp('a � nullo')
end

if a<0; disp('a negativo'); end