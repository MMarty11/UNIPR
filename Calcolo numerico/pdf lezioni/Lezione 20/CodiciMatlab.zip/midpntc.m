function int=midpntc(f,a,b,m)
%formula del punto medio composita
%INPUT
%f=funzione integranda
%a,b=estremi intervallo di integrazione
%m=n.sottintervalli di decomposizione
H=(b-a)/m;
x=a+H/2:H:b;
y=f(x);
int=sum(y)*H;