function int=CavSimpc(f,a,b,m)
%formula di Cavalieri Simpson composita
%INPUT
%f=funzione integranda
%a,b=estremi intervallo di integrazione
%m=n.sottintervalli di decomposizione
H=(b-a)/m;
x=a:H/2:b;
y=f(x);
int=H/6*(y(1)+2*sum(y(3:2:2*m-1))+4*sum(y(2:2:2*m))+y(2*m+1));