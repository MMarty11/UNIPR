%Esercizio integrazione numerica
clear
clc
close all

fun=@(x) x.*exp(-x).*cos(2*x);
a=0; b=2*pi;
x=linspace(a,b,200);
plot(x,fun(x))
grid on
ylabel('funzione integranda')
I_esatto=(3*(exp(-2*pi)-1)-10*pi*exp(-2*pi))/25
%I_Matlab=integral(fun,a,b)
m=1000;
tic
I_punto_medio_c=midpntc(fun,a,b,m)
toc
tic
I_trapezio_c=trapezc(fun,a,b,m)
toc
%I_trapz_Matlab=trapz(a:(b-a)/m:b,fun(a:(b-a)/m:b))
tic
I_CavSimp_c=CavSimpc(fun,a,b,m)
toc
err=[abs(I_esatto-I_punto_medio_c) abs(I_esatto-I_trapezio_c)...
    abs(I_esatto-I_CavSimp_c)]

