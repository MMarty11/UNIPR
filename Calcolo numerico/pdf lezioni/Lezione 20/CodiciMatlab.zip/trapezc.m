function int=trapezc(f,a,b,m)
%formula del trapezio composita
%INPUT
%f=funzione integranda
%a,b=estremi intervallo di integrazione
%m=n.sottintervalli di decomposizione
H=(b-a)/m;
x=a:H:b;
y=f(x);
int=H/2*(y(1)+2*sum(y(2:m))+y(m+1));